# CHANGELOG BUDGETREPORT FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## 1.0.1

Update from 1.0
- Project listing: filtered to only applicable for project with budget (project with no/negative budget is not listed)
- Update permission settings

## 1.0

Initial version
- Display project budget report in chart & table
- Only applicable for open project

